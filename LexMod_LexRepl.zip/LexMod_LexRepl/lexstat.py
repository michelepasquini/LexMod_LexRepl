import sys
import lingpy

from lingpy import *

file_metadata='cldf/servamalagasy-1.1_without_snow_ice/cldf-metadata.json'

if len(sys.argv) > 1: file_metadata = sys.argv[1]


#---------------------------------------------------------
# read the dataset
#---------------------------------------------------------

print("Reading the dataset ...\n")

wl = Wordlist.from_cldf(file_metadata)



lex = LexStat(wl)

lex.get_scorer(runs=10000)

lex.cluster(method='lexstat', cluster_method='infomap', threshold=0.55, ref='infomapid')

lex.output('tsv', filename='tsv/lexstat', ignore='all', prettify=False)
