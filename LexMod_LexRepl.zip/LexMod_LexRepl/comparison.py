import lingpy
import sys

from lingpy import *
from lingpy.evaluate.acd import bcubes
from library import *

threshold = 0.5

if len(sys.argv) > 1: threshold =  float(sys.argv[1])


#---------------------------------------------------------
# read the dataset
#---------------------------------------------------------

print("Reading the dataset ...\n")

wl = Wordlist('tsv/lexstat.tsv')


#---------------------------------------------------------
# export genealogical distances in MEGA format
#---------------------------------------------------------

print("Exporting genealogical distances T_R_infomap in meg/T_R_infomap.meg ...\n")

export_meg(distance_matrix(wl,"R",cogid="infomapid"),wl.language,"T_R_infomap",title="T_R_infomap")


#---------------------------------------------------------
# run PSV algorithm for automated cognate detection
#---------------------------------------------------------

print("Running PSV algorithm ...\n")

psv_cogn_detect( wl, threshold = threshold )


#---------------------------------------------------------
# B-cubes F-scores
#---------------------------------------------------------

print("Computing B-cubed F-scores ...\n")

bcubes(wl, "infomapid", "psv_id")
