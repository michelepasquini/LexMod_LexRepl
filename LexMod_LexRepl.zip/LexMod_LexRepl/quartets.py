import lingpy
import library
import sys
import numpy as np

from lingpy import *
from library import *
from math import log10, floor

if len(sys.argv) > 1: file =  sys.argv[1]
if len(sys.argv) > 2: file_ref =  sys.argv[2]



#---------------------------------------------------------
def round_to_2(x):
	return round(x, 1-int(floor(log10(abs(x)))))



#---------------------------------------------------------

def butterfly(a,b,c,d,e,f):

#  | .  a  b  c |
#  | a  .  d  e |
#  | b  d  .  f |
#  | c  e  f  . |

	if ( a==b and b==c and c==a ):
		if ( d==e ):
			nb = 12
# it's a star:
#	---------- 1
#       |
# -------
#       |  ------- 2
#       ---|
#          |  ---- 3
#          ---|
#             ---- 4

		elif ( d==f ):
			nb = 13
# it's a star:
#	---------- 1
#       |
# -------
#       |  ------- 3
#       ---|
#          |  ---- 2
#          ---|
#             ---- 4

		else:
			nb=14

	elif ( a==d and d==e and e==a ):
		if ( b==c ):
			nb = 21
		elif ( b==f ):
			nb = 23
		else:
			nb=24

	elif ( d==b and b==f and f==d ):
		if ( a==c ):
			nb = 31
		elif ( a==e ):
			nb = 32
		else:
			nb=34
		
	elif ( e==f and f==c and c==e ):
		if ( a==b ):
			nb = 41
		elif ( a==d ):
			nb = 42
		else:
			nb=43
# it's a star:
#	---------- 4
#       |
# -------
#       |  ------- 3
#       ---|
#          |  ---- 1
#          ---|
#             ---- 2


	elif ( a<b and a<c):
		nb = 2
# it's a butterfly:
#             ---- 1
#	------|
#       |     ---- 2
# -------
#       |  ------- 3
#       ---|
#          ------- 4

	elif ( b<a and b<c):
		nb = 3
# it's a butterfly:
#             ---- 1
#	------|
#       |     ---- 3
# -------
#       |  ------- 2
#       ---|
#          ------- 4

	else:
		nb = 4
# it's a butterfly:
#             ---- 1
#	------|
#       |     ---- 4
# -------
#       |  ------- 2
#       ---|
#          ------- 3

	return nb



#---------------------------------------------------------

dist=dist2upgma_dist(import_meg(file))
dist_ref=dist2upgma_dist(import_meg(file_ref))

ntot=0
nqdiff=0

nbtot=0
nbdiff=0

for i1 in range(len(dist[1])-3):
	for i2 in range(i1+1,len(dist[1])-2):
		for i3 in range(i2+1,len(dist[1])-1):
			for i4 in range(i3+1,len(dist[1])):

				nb=butterfly(dist[i1][i2],dist[i1][i3],dist[i1][i4],dist[i2][i3],dist[i2][i4],dist[i3][i4])
				nb_ref=butterfly(dist_ref[i1][i2],dist_ref[i1][i3],dist_ref[i1][i4],dist_ref[i2][i3],dist_ref[i2][i4],dist_ref[i3][i4])

				ntot = ntot + 1
				if not nb == nb_ref and (nb < 10 or nb_ref < 10): nqdiff = nqdiff + 1

				if not nb_ref > 10:
					nbtot = nbtot + 1
					if not nb == nb_ref: nbdiff = nbdiff + 1


print("  QD =     different_quartets /        total_quartets  =  %8i / %8i  =  %7.5f" %(nqdiff,ntot,round_to_2(nqdiff/ntot)))
print(" GQD =    different_butterfl. / total_butterfl._(ref)  =  %8i / %8i  =  %7.5f" %(nbdiff,nbtot,round_to_2(nbdiff/nbtot)))
