import lingpy
import numpy as np
from lingpy import *
from itertools import product
from math import log, sqrt


def NLD_matrix_words(
	words,  # a list of words
	):
	"""
	Function computes distance matrix for a list of words using NLD distance (Normalized Levenshtein Distance).
	"""

	matrix = [[0 for i in range(len(words))] for j in range(len(words))]

	# cycle on language pairs
	for i in range(len(words)-1):
		for j in range(i+1,len(words)):

			matrix[i][j] = edit_dist(words[i], words[j], normalized=True)
			matrix[j][i] = matrix[i][j]

	return matrix



def genealogical(
	matrix,                  # distance matrix
	):
	"""
	Converts a lexical distance matrix into a genealogical one.
	"""
	genealogical = matrix
	for i in range(len(matrix)):
		for j in range(i):
			genealogical[i][j] = - log(1 - matrix[i][j])/2
			genealogical[j][i] = matrix[i][j]

	return genealogical



def distance_matrix(
	wl,                      # wordlist object
	kind,                    # {"NLD", "R", "M", "MR"}
	data  = 'value',
	cogid = 'psv_id',
	time  = True             # returns genealogical distances instead of lexical distances
	):
	"""
	Function computes distance matrix of all pairs of languages in wordlist.
	kind: Select between:
           "NLD" : mean NLD distance (Normalized Levenshtein Distance) over all concepts;
           "M"   : mean NLD distance only over concepts for which words are cognates     (cogid is required);
           "R"   : mean dichotomic distance     ( 0  if words are cognates, 1 otherwise) (cogid is required);
	   "MR"  : mean NLD-dichotomic distance (NLD if words are cognates, 1 otherwise) (cogid is required);
	"""

	distance = [[0 for i in range(wl.width)] for j in range(wl.width)]

	# cycle on language pairs
	for (i, langA), (j, langB) in product(enumerate(wl.language), repeat=2):

		if i < j:

			# get the two dictionaries
			dictA , dictB = [wl.get_list(language=lang, entry=data) for lang in [langA, langB]]
			cogA , cogB = [wl.get_list(language=lang, entry=cogid) for lang in [langA, langB]]

			distanceAB = []

			# cycle on concepts
			for k in range(wl.height):

				if kind == 'NLD' or ( kind != 'R' and cogA[k] == cogB[k]):
					distanceAB.append(edit_dist(dictA[k], dictB[k], normalized=True))

				elif kind != 'M':
					if cogA[k] == cogB[k]:
						distanceAB.append(0.)
					else:
						distanceAB.append(1.)


			distance[i][j] = sum(distanceAB) / len(distanceAB)
			distance[j][i] = distance[i][j]

		elif i == j:
			distance[i][j] = 0.

	if time:
		genealogical(distance)

	return distance



def psv_cogn_detect(
	wl,                  # wordlist object
	data      = 'value',
	threshold = 0.5,
	cogid     = 'psv_id' # resulting cognacy ID
	):
	"""
	Function computes clusters of cognates for each concept in wordlist
	"""

	# checking if cogid already exists
	ncol=0
	names=list(wl.header)
	for i in range(len(names)):
		if names[i] == cogid: ncol=i

	if ncol == 0:
		idxs = {idx: idx for idx in wl}
		wl.add_entries(cogid, idxs, lambda x: 0)
		ncol=len(wl.header)-1


	# nID counts the clusters
	nID=0

	# cycle on the concepts
	for concept in wl.concept:

		words = wl.get_list(concept=concept, entry=data, flat=True)

		# distances is a matrix storing all the pairs of NLD distances between words
		distances=NLD_matrix_words(words)

		# cog stores the cognate ID for actual concept, initialized to 0
		cog = [0 for i in range(len(words))]

		# main cycle on words list	
		for i in range(len(words)):

			# new cluster found
			if cog[i] == 0:

				nID = nID +1
				cog[i] = nID
	
				# cluster_elements stores the pointers to the words that belong to the new cluster, i is the first of them.
				# all the distances of these words have to be checked, to find other elements of the new cluster

				cluster_elements = []
				cluster_elements.append(i)

				k1=0

				# cycle on elements of the new cluster
				while k1 < len(cluster_elements):

					k = cluster_elements[k1]

					# secondary loop on words list ...
					for j in range(len(words)):

						# ... searching for those words still without cognacy label (cog[j]=0)
						# and next to the k-th element of the new cluster (distances[k][j] < threshold)
						if cog[j] == 0 and distances[k][j] < threshold:
							cog[j] = nID
							cluster_elements.append(j)

					k1 = k1 + 1

		# passes the result to wordlist
		pointers = wl.get_list(concept=concept, flat=True)
		for i in range(len(pointers)):
			wl[pointers[i]][ncol] = cog[i]



def export_meg(
	matrix,                  # distance matrix
	languages,               # python list of names
	filename,                # without extension
	title = ""
	):
	"""
	Function exports distance matrix in meg format (MEGA software, https://www.megasoftware.net ).
	"""
	nsize=len(languages)

	for i in range(nsize):
		languages[i]=languages[i].replace(" ","_")
		languages[i]=languages[i].replace("'","")

	f = open("meg/" + filename + ".meg", "w")
	f.write(f"#mega\n")
	f.write(f"!Title: {title};\n")
	f.write(f"!Format DataType=Distance DataFormat=LowerLeft NTaxa={nsize};\n")

	int="[   "
	for i in range(nsize):
		f.write(f"[{i+1}] #{languages[i]}\n")
		int=int+"      "+str(i+1)+"    "

	int=int+"]"
	f.write(f"{int}\n")

	for i in range(nsize):
		f.write(f"[{i+1}]")

		for j in range(i):
			f.write(f"    {matrix[i][j]:.5f}")

		f.write(f"\n")

	f.close()



def import_meg(
	filename    # meg file
	):
	"""
	Function imports distance matrix from file in meg format (MEGA software, https://www.megasoftware.net ).
	"""

	a=[1]
	f = open(filename, "r")
	while not a[0] == "[":
		a=f.readline().split()

	nsize=int(a[-2])
	distance = [[0 for i in range(nsize)] for j in range(nsize)]

	f.readline()
	for i in range(1,nsize):
		a=f.readline().split()
		for j in range(i):
			distance[i][j]=float(a[j+1])
			distance[j][i]=distance[i][j]

	f.close()

	return distance



def bins(values,width=0.0001):
	"""
	Function computes bins for histograms of values
	"""

	values.sort()

	bins=[]

	i=0

	while i < len(values):

		j=i
		while j +1< len(values) and abs( values[i]- values[j+1] ) <= width:
			j = j + 1

		bins.append( [ (values[i]+values[j])/2 , 100*(1+j-i)/len(values) ] )

		i = j + 1
	
	return bins	



def non_cognate_distribution(
	wl,                  # wordlist object
	data  = 'value',
	cogid = 'psv_id',
	interv = ""         # intervals in 2-ple format: left and right extreme
	):

	"""
	Function computes NLD distribution of cognate pairs, adopting the already defined intervals distr
	"""

	ntot=0
	distr = [0 for i in range(len(interv))]

	# cycle on concepts
	for conc in wl.concept:

		word , cogn = [wl.get_list(row=conc, entry=key, flat=True) for key in [data, cogid]]

		for (i, wordA), (j, wordB) in product(enumerate(word), repeat=2):

			if i < j and cogn[i] != cogn[j]:

				x = edit_dist(wordA, wordB, normalized=True)
				n=1
				while x > interv[n][1]: n = n + 1

				distr[n] = distr[n] + 1
				ntot = ntot +1

	for i in range(len(distr)):
		distr[i] = distr[i]/ntot

	return distr



def LeCam_distance( f , g ):

	"""
	Function computes Le Cam distance between two discrete distributions f and g
	"""

	LeCam = 0.

	for i in range(len(f)):
		LeCam = LeCam + ( f[i] - g[i] ) * ( f[i] - g[i] ) / ( f[i] + g[i] )

	LeCam = sqrt(LeCam/2)

	return LeCam



def dist2upgma_dist(
	matrix,      # distance matrix
	):
	"""
	Function calculates UPGMA tree, then gives back tip-to-tip distances as a distance matrix
	"""
	m=np.array(matrix)
	mv=2*m.max()

	upgma = [[] for j in range(len(m))]

	nleafs = [1 for j in range(len(m))]
	leaf = [[j for i in range(1)] for j in range(len(m))]

	for i in range(len(m)):
		for j in range(i+1):
			m[i][j]=mv

	while len(m) > 1:

		p=np.unravel_index(np.argmin(m), m.shape)

		for i in range(0,len(m)):
			if not i==p[0] and not i==p[1]: m[min(i,p[0])][max(i,p[0])]=(nleafs[p[0]]*m[min(i,p[0])][max(i,p[0])]+nleafs[p[1]]*m[min(i,p[1])][max(i,p[1])])/(nleafs[p[0]]+nleafs[p[1]])

		nleafs[p[0]]=nleafs[p[0]]+nleafs[p[1]]
		nleafs.pop(p[1])

		upgma[p[0]].append(m.min())
		upgma[p[0]].extend(upgma[p[1]])
		upgma.pop(p[1])

		leaf[p[0]].extend(leaf[p[1]])
		leaf.pop(p[1])

		m=np.delete(m,p[1],0)
		m=np.delete(m,p[1],1)

	upgma=np.array(upgma[0])
	leaf=leaf[0]

	dist = [[0.0 for i in range(len(matrix))] for j in range(len(matrix))]

	for i in range(len(upgma)):
		for j in range(i,len(upgma)):
			dist[leaf[i]][leaf[j+1]] = upgma[i:j+1].max()
			dist[leaf[j+1]][leaf[i]] = dist[leaf[i]][leaf[j+1]]

	return dist
