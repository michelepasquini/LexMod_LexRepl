import random
import lingpy
import library
import sys

from random import *
from lingpy import *
from library import bins

file_metadata='cldf/servamalagasy-1.1_without_snow_ice/cldf-metadata.json'
number_iterations = 600000

if len(sys.argv) > 1: file_metadata = sys.argv[1]
if len(sys.argv) > 2: number_iterations =  int(sys.argv[2])


#---------------------------------------------------------
# read the dataset
#---------------------------------------------------------

print("Reading the dataset ...\n")

wl = Wordlist.from_cldf(file_metadata)


#---------------------------------------------------------
# Percentage frequency of NLD distribution for pairs of words with different concepts
#---------------------------------------------------------

print("Calculating % frequency of NLD distribution for pairs with different concepts ...")

# list of NLD values
values = []

for i in range(number_iterations):

	# first random choice from the database
	langA = choice(wl.language)
	concA = choice(wl.concept)

	wordA = wl.get_dict(doculect=langA, entry="value")[concA][0]

	# second random choice from the database
	# it has to differ from the first choice in both language and concept
	langB = langA
	while langB == langA:
		langB = choice(wl.language)

	concB = concA
	while concB == concA:
		concB=choice(wl.concept)

	wordB = wl.get_dict(doculect=langB, entry="value")[concB][0]

	values.append(edit_dist(wordA, wordB, normalized=True))

diff_conc=bins(values)

f = open("tabular/frequency_NLD_different_concepts.txt", "w")
f.write(f"NLD\tPercentage frequency\n")
for (nld, freq) in diff_conc:
	f.write(f"{nld:.5f}\t{freq:.5f}\n")
f.close()

print("Results in tabular/frequency_NLD_different_concepts.txt\n")



#---------------------------------------------------------
# Percentage frequency of NLD distribution for pairs of words with the same concept
#---------------------------------------------------------

print("Calculating % frequency of NLD distribution for pairs with the same concept ...")

# list of found values of NLD
values = []

# cycle on the concepts
for concept in wl.concept:

	words = wl.get_list(concept=concept, entry='value', flat=True)

	# cycle on the pairs of words from different languages
	for i in range(len(words)):
		for j in range(i):

			values.append(edit_dist(words[i], words[j], normalized=True))

same_conc=bins(values)

f = open("tabular/frequency_NLD_same_concept.txt", "w")
f.write(f"NLD\tPercentage frequency\n")
for (nld, freq) in same_conc:
	f.write(f"{nld:.5f}\t{freq:.5f}\n")
f.close()

print("Results in tabular/frequency_NLD_same_concepts.txt")

