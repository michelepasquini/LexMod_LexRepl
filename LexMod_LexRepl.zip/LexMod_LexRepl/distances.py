import lingpy
import library
import sys

from lingpy import *
from library import *

file_metadata='cldf/servamalagasy-1.1_without_snow_ice/cldf-metadata.json'
threshold = 0.5

if len(sys.argv) > 1: file_metadata = sys.argv[1]
if len(sys.argv) > 2: threshold =  float(sys.argv[2])


#---------------------------------------------------------
# read the dataset
#---------------------------------------------------------

print("Reading the dataset ...\n")

wl = Wordlist.from_cldf(file_metadata)



#---------------------------------------------------------
# run PSV algorithm for automated cognate detection
#---------------------------------------------------------

print("Running PSV algorithm ...\n")

psv_cogn_detect(wl,threshold = threshold)



#---------------------------------------------------------
# Percentage frequency of NLD distribution for pairs of cognate words
#---------------------------------------------------------

print("Calculating % frequency of NLD distribution for pairs of cognate words ...")

# list of found values of NLD
values = []

# cycle on the concepts
for concept in wl.concept:

	word , cogn = [wl.get_list(row=concept, entry=key, flat=True) for key in ['value', 'psv_id']]

	# cycle on the concepts
	for (i, wordA), (j, wordB) in product(enumerate(word), repeat=2):

		if i < j and cogn[i] == cogn[j]:

			values.append(edit_dist(wordA, wordB, normalized=True))

cognates=bins(values)

f = open("tabular/frequency_NLD_cognates.txt", "w")
f.write(f"NLD\tPercentage frequency\n")
for (nld, freq) in cognates:
	f.write(f"{nld:.5f}\t{freq:.5f}\n")
f.close()

print("Results in tabular/frequency_NLD_cognates.txt\n")



#---------------------------------------------------------
# compare modifications distance matrix and replacements distance matrix
#---------------------------------------------------------

print("Calculating DR vs DM ...")

dm = distance_matrix(wl,"M",time=False)
dr = distance_matrix(wl,"R",time=False)

f = open("tabular/DR_vs_DM.txt", "w")
f.write(f"DM\tDR\n")
for (i, langA), (j, langB) in product(enumerate(wl.language), repeat=2):
	if i < j :
		f.write(f"{dm[i][j]:.5f}\t{dr[i][j]:.5f}\n")
f.close()

print("Results in tabular/DR_vs_DM.txt\n")



#---------------------------------------------------------
# export genealogical distances in MEGA format
#---------------------------------------------------------

print("Exporting genealogical distances T_NLD in meg/T_NLD.meg ...\n")
export_meg(distance_matrix(wl,"NLD",cogid=""),wl.language,"T_NLD",title="T_NLD")

print("Exporting genealogical distances T_M   in meg/T_M.meg   ...\n")
export_meg(genealogical(dm),wl.language,"T_M",title="T_M")

print("Exporting genealogical distances T_R   in meg/T_R.meg   ...\n")
export_meg(genealogical(dr),wl.language,"T_R",title="T_R")

print("Exporting genealogical distances T_MR  in meg/T_MR.meg  ...\n")
export_meg(distance_matrix(wl,"MR"),wl.language,"T_MR",title="T_MR")
