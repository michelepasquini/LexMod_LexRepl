import lingpy
import library
import sys

from lingpy import *
from library import *

file_metadata='cldf/servamalagasy-1.1_without_snow_ice/cldf-metadata.json'
min_frequency = 0.005

if len(sys.argv) > 1: file_metadata = sys.argv[1]
if len(sys.argv) > 2: min_frequency =  float(sys.argv[2])


#---------------------------------------------------------
# read the dataset
#---------------------------------------------------------

print("Reading the dataset ...\n")

wl = Wordlist.from_cldf(file_metadata)



#---------------------------------------------------------
# Absolute frequency of NLD distribution for pairs of words with different concepts
#---------------------------------------------------------

print("Grouping NLD frequency of different concepts in appropriate intervals ...")

f_distr = [ 0. ]
NLD_interv  = [ [0., 0.] ]

lines = open("tabular/frequency_NLD_different_concepts.txt","r").readlines()
for line in lines[1:]:
	nld, freq = line.replace("\n","").split("\t")
	if len(freq) < 1: continue
	nld=float(nld)
	freq=float(freq)/100.

	if f_distr[-1] >= min_frequency:
		NLD_interv[-1][1] = ( NLD_interv[-1][1] + nld )/2
		NLD_interv.append([ NLD_interv[-1][1] , nld ])
		f_distr.append(0.)

	NLD_interv[-1][1] = nld
	f_distr[-1] = f_distr[-1] + freq

f = open("tabular/intervals_NLD_different_concepts.txt", "w")
f.write(f"NLD interval\t\tAbsolute frequency\n")
for i in range(len(f_distr)): 
	f.write(f"{NLD_interv[i][0]:.5f}\t{NLD_interv[i][1]:.5f}\t{f_distr[i]:.4f}\n")
f.close()

print("Results in tabular/intervals_NLD_different_concepts.txt\n")



#---------------------------------------------------------
# Threshold optimization
#---------------------------------------------------------

print("Searching for the optimal threshold ...")

f = open("tabular/Le_Cam_distance.txt", "w")
f.write(f"Threshold\tLe Cam distance\n")

best_distance=99999

for i in range(0, 101, 5):

	psv_cogn_detect(wl,threshold = i/100)

	g_distr=non_cognate_distribution(wl,interv=NLD_interv)

	x=LeCam_distance(f_distr,g_distr)

	if x < best_distance:
		best_distance = x
		best_threshold = i/100

	f.write(f"{i/100:.2f}\t{x:.5f}\n")

f.close()

print(f"Optimal threshold = {best_threshold:.2f} (Le Cam distance = {best_distance:.4f})")

print("Results in tabular/Le_Cam_distance.txt")
